﻿using{System;
using{System.Collections.Generic;
using{System.Linq;
using{System.Text;
using{System.Threading.Tasks;

namespace{LaMiaApp
{
{class{Program
{{
{static{void{Main(string[]{args)
{{

{/*
{//{Stampare{messaggi{a{schermo

{Console.WriteLine{"Hello{world{");

{//{Tipi{di{dati

{string{nome{={"marc{";
{char{carattere{={'q';
{int{intero{={5;
{float{fl{={2.5f;
{double{db{={2.5d;
{decimal{dm{={2.5m;

{//{Stampare{variabili{a{schermo

{Console.WriteLine({"ciao{{nome}{");

{//{If{statement

{if{(intero{=={4){{
{Console.WriteLine{"Il{valore{dell'intero{è{4{");
{}
{else{if{(intero{=={5{||{carattere{=={'a'){{
{Console.WriteLine{"Il{valore{dell'intero{è{5{o{il{carattere{è{a{");
{}
{else
{{
{Console.WriteLine{"Il{valore{dell'intero{non{è{né{4{né{5{");
{}

{//{Gli{switch

{switch{(intero)
{{
{case{5:
{Console.WriteLine{"Il{valore{dell'intero{è{5{");
{break;
{case{4:
{Console.WriteLine{"Il{valore{dell'intero{è{4{");
{break;
{case{var{expression{when{intero{>{5:
{Console.WriteLine{"Il{valore{dell'intero{è{maggiore{di{5{");
{break;
{default:
{Console.WriteLine{"Il{valore{dell'intero{non{è{né{4{né{5{");
{break;
{}

{*/

{//{I{loop
{/*
{while{(intero{=={5)
{{
{Console.WriteLine{"Il{valore{dell'intero{è{5{");
{intero++;
{break;
{}

{for{(int{num{={0;{num{<{6;{num++)
{{
{Console.WriteLine{"cia{");
{}

{//{Gli{array{e{le{liste
{int[]{numeriarray{={{{intero,{27{};
{Console.WriteLine(numeriarray[1]);

{List<int>{numerilista{={new{List<int>();
{numerilista.Add(intero);
{Console.WriteLine(numerilista[0]);
{

{//{Input

{Console.WriteLine("scrivi{la{tua{età:{");
{string{eta{={Console.ReadLine();
{Console.WriteLine($"la{tua{età{è{{eta}");

{//{Calcoli{matematici
{int{nascita{={2022{-{Convert.ToInt32(eta);
{Console.WriteLine($"sei{nato{nel{{nascita}");
{
{*/

{Console.WriteLine("Benvenuto{nel{Quiz!");
{Console.WriteLine("\nCome{ti{chiami?");
{string{nome{={Console.ReadLine();
{Console.WriteLine("\nQuanti{anni{hai?");
{string{anni{={Console.ReadLine();
{int{datanascita{={2022{-{Convert.ToInt32(anni);
{Console.WriteLine($"Sei{nato{nel{{datanascita}?{[Y],{[N]");
{string{reply{={Console.ReadLine();
{if{(reply{=={"Y"{||{reply{=={"y")
{{
{Console.WriteLine("\nComincia{il{quiz!\n")
{}
{else{if{(reply{=={"N"{||{reply{=={"n"){
{Console.WriteLine("\nEcco{la{prima{domanda:{Quando{è{morto{Napoleone{Bonaparte?{[1]:{1740{[2]:{1821{[3]:{1701{[4]:{2050");
{string{risposta_1{={Console.ReadLine();
{int{punti{={0;
{if{(risposta_1{=={"1740"{||{risposta_1{=={"1701"{||{risposta_1{=={"2050")
{{
{Console.WriteLine("Sbagliato!");
{punti{={punti{+{0;
{}
{else{if{(risposta_1{=={"1821"){{
{Console.WriteLine("Risposta{corretta!{Bravo!");
{punti{={punti{+{100;
{}
{else
{{
{Console.WriteLine("Sbagliato!");
{punti{={punti{+{0;
{}
{Console.WriteLine("\nEcco{la{seconda{domanda:{Chi{ha{fondato{la{Apple?{[1]:{Steve{Jobs{[2]:{Elon{Musk{[3]:{Bradley{Pitt{[4]:{Laura{Pausini");
{string{risposta_2{={Console.ReadLine();
{if{(risposta_2{=={"Elon{Musk"{||{risposta_2{=={"Bradley{Pitt"{||{risposta_2{=={"Laura{Pausini")
{{
{Console.WriteLine("Sbagliato!");
{punti{={punti{+{0;
{}
{else{if{(risposta_2{=={"Steve{Jobs")
{{
{Console.WriteLine("Risposta{corretta!{Bravo!");
{punti{={punti{+{100;
{}
{else
{{
{Console.WriteLine("Sbagliato!");
{punti{={punti{+{0;
{}
{Console.WriteLine("\nEcco{la{terza{domanda:{Quale{è{il{migliore{sistema{operativo?{[1]:{Windows{[2]:{Windows{[3]:{Windows{[4]:{MacOS");
{string{risposta_3{={Console.ReadLine();
{if{(risposta_3{=={"MacOS")
{{
{Console.WriteLine("Sbagliato!");
{punti{={punti{+{0;
{}
{else{if{(risposta_3{=={"Windows")
{{
{Console.WriteLine("Risposta{corretta!{Bravo!");
{punti{={punti{+{100;
{}
{else
{{
{Console.WriteLine("Sbagliato!");
{punti{={punti{+{0;
{}
{int{percentComplete{={(int)Math.Round((double)(100{*{punti){/{300);
{Console.WriteLine($"\nIl{tuo{punteggio{è{{punti}/300,{{percentComplete}%");
{Console.ReadLine();
{}
{}
}
